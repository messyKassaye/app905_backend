<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TabletPromotionBank extends Model
{
    //

    public function advertPaymentTransaction(){
        return $this->hasMany(AdvertPaymentTransaction::class,'bank_id');
    }
}
