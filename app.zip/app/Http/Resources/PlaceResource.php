<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class PlaceResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'country'=>$this->country,
            'city'=>$this->city,
            'latitude'=>$this->latitude,
            'longtude'=>$this->longtude,
            'adverts'=>$this->advert
        ];
    }
}
