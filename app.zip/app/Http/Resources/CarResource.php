<?php

namespace App\Http\Resources;

use App\CarCategory;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class CarResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param \Illuminate\Http\Request $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'plate_number' => $this->plate_number,
            'car_category' => $this->category,
            'week' => $this->week,
            'adverts' => count(CarAdvertResource::collection($this->advert)),
            'advert_info'=>[
                "video"=>$this->findMediaNumber($this->id,1),
                "audio"=>$this->findMediaNumber($this->id,2),
                "image"=>$this->findMediaNumber($this->id,3)
            ],
            'driver' => $this->driver,
            'driver_link' => $this->driverLink,
            'working_place' => $this->workingPlace,
            'working_tablet' => $this->tablet
        ];
    }

    public function findMediaNumber($carId,$mediaId){
        $count = DB::table('car_adverts')->join('adverts',function ($join){
            $join->on('adverts.id','car_adverts.advert_id');
        })->where(['car_adverts.car_id'=>$carId,'adverts.advertisement_media_type_id'=>$mediaId])->get();

        return count($count);
    }
}
