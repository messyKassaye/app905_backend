<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AdminAdvertResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'company_id'=>$this->company_id,
            'product_name'=>$this->product_name,
            'required_views_number'=>$this->required_views_number,
            'current_view'=>count($this->carAdvert),
            'is_all_over_ethiopia'=>$this->is_all_over_ethiopia,
            'advertisement_media_type_id'=>$this->advertisement_media_type_id,
            'advert_media_type'=>new AdvertisementMediaTypeResource($this->advertMediaType),
            'media_path'=>$this->media_path,
            'status'=>$this->status,
            'company'=>new CompanyResource($this->company),
            'media'=>$this->advertMediaType,
            'views'=>$this->views,
            'payment_status'=>new AdvertPaymentTransactionResource($this->paymentStatus),
            'adverted_cars'=>count($this->carAdvert),
            'advertisement_places'=>PlaceResource::collection($this->places)
        ];
    }
}
