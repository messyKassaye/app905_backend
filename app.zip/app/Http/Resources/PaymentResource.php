<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class PaymentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'payed_at'=>Carbon::parse($this->created_at)->diffForHumans(),
            'amount'=>$this->amount,
            'description'=>$this->description,
            'payment_type'=>$this->payment_type,
            'week'=>$this->weeks[0]->week_no,
        ];
    }
}
