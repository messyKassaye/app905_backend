<?php

namespace App\Http\Resources;

use App\Advert;
use App\Car;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class AdminCarAdvertResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'advert_time' => $this->advert_time,
            'financing_time' => $this->financing_time,
            'picture'=>$this->picture,
            'number_of_viewers'=>$this->number_of_viewers,
            'created_at'=>Carbon::parse($this->created_at)->toDateString(),
            'advert' => Advert::where('id',$this->advert_id)->with('advertMediaType')->with('company')->get(),
            'car'=>Car::where('id',$this->car->id)->with('tablet')->get(),
            'status' => $this->status,
            'weeks'=>$this->weeks,
        ];
    }
}
