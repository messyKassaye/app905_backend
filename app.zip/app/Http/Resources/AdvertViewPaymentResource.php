<?php

namespace App\Http\Resources;

use App\CarAdvert;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\DB;

class AdvertViewPaymentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'total_payment'=>$this->total_payment,
            'car_advert'=>DB::table('car_adverts')
                ->join('adverts','adverts.id','=','car_adverts.id')
                ->join('companies','companies.id','=','adverts.company_id')
                ->where('car_adverts.id',$this->car_advert_id)->select('companies.name as company_name','adverts.product_name',
                    'car_adverts.advert_time','car_adverts.status')
                ->get()
        ];
    }
}
