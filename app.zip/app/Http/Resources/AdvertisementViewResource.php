<?php

namespace App\Http\Resources;

use App\Advert;
use App\Car;
use Illuminate\Http\Resources\Json\JsonResource;

class AdvertisementViewResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'advert'=>Advert::find($this->advert_id),
            'number_of_view'=>$this->number_of_view,
            'car'=>Car::where('id',$this->car->id)
                ->with('workingPlace')->get()
        ];
    }
}
