<?php

namespace App\Http\Resources;

use App\Api\V1\Services\FileZipperService;
use Illuminate\Http\Resources\Json\JsonResource;

class AdvertsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */


    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'product_name'=>$this->product_name,
            'required_views_number'=>$this->required_views_number,
            'status'=>$this->status,
            'payment_status'=>$this->paymentStatus===null?'not_payed':new AdvertPaymentTransactionResource($this->paymentStatus),
            'company'=>$this->company,
            'advert_media_type'=>$this->advertMediaType,
            'views'=>count($this->carAdvert),
            'advert_places'=>$this->places,
        ];
    }
}
