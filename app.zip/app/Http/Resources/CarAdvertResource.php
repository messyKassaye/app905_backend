<?php

namespace App\Http\Resources;
use App\Advert;
use App\Car;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class CarAdvertResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'advert_time' =>$this->advert_time,
            'financing_time' => $this->financing_time,
            'picture'=>$this->picture,
            'number_of_viewers'=>$this->number_of_viewers,
            'created_at'=>$this->created_at,
            'detail'=>new AdvertsResource($this->advert),
            'status' => $this->status,
            'weeks'=>$this->weeks,
        ];
    }
}
