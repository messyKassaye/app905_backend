<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class AdvertPaymentTransactionResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'approved_by'=>$this->approvedBy,
            'deposited_by_name'=>$this->deposited_by_name,
            'transaction_ref_number'=>$this->transaction_ref_number,
            'transaction_date'=>$this->transaction_date,
            'receipt_image'=>$this->receipt_image,
            'bank'=>$this->bank
        ];
    }
}
