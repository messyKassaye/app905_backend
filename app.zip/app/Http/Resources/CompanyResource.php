<?php

namespace App\Http\Resources;

use App\Advert;
use Illuminate\Http\Resources\Json\JsonResource;

class CompanyResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return  [
            'id'=>$this->id,
            'name'=>$this->name,
            'phone'=>$this->phone,
            'website'=>$this->website,
            'user'=>$this->user,
            'adverts'=>Advert::where('company_id',$this->id)->orderBy('id','DESC')
                ->with('advertMediaType')->with('places')->with('views')
                ->with('carAdvert')->with('paymentStatus')
                ->with('paymentStatus.bank')->with('paymentStatus.approvedBy')
                ->with('company')->get()
        ];
    }
}
