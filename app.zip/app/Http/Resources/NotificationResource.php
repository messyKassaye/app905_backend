<?php

namespace App\Http\Resources;

use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;

class NotificationResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id'=>$this->id,
            'notifier_id'=>$this->notifier_id,
            'notification_path'=>$this->notification_path,
            'entity'=>new EntityTypeResource($this->entityType),
            'message'=>$this->message,
            'path'=>$this->notification_path,
            'created_at'=>Carbon::parse($this->created_at)->diffForHumans(),
            'status'=>$this->status,
        ];
    }
}
