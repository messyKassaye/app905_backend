<?php

namespace App\Http\Controllers;

use App\CarDriver;
use Illuminate\Http\Request;

class CarDriverController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function show(CarDriver $carDriver)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function edit(CarDriver $carDriver)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CarDriver $carDriver)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarDriver $carDriver)
    {
        //
    }
}
