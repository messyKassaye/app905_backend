<?php

namespace App\Http\Controllers;

use App\AdvertisingEngineerPortfolio;
use Illuminate\Http\Request;

class AdvertisingEngineerPortfolioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertisingEngineerPortfolio  $advertisingEngineerPortfolio
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertisingEngineerPortfolio $advertisingEngineerPortfolio)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertisingEngineerPortfolio  $advertisingEngineerPortfolio
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertisingEngineerPortfolio $advertisingEngineerPortfolio)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertisingEngineerPortfolio  $advertisingEngineerPortfolio
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdvertisingEngineerPortfolio $advertisingEngineerPortfolio)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertisingEngineerPortfolio  $advertisingEngineerPortfolio
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertisingEngineerPortfolio $advertisingEngineerPortfolio)
    {
        //
    }
}
