<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PivotController extends Controller
{
    //
}
