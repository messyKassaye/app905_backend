<?php

namespace App\Http\Controllers;

use App\CarsWeek;
use Illuminate\Http\Request;

class CarsWeekController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CarsWeek  $carsWeek
     * @return \Illuminate\Http\Response
     */
    public function show(CarsWeek $carsWeek)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CarsWeek  $carsWeek
     * @return \Illuminate\Http\Response
     */
    public function edit(CarsWeek $carsWeek)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CarsWeek  $carsWeek
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CarsWeek $carsWeek)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CarsWeek  $carsWeek
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarsWeek $carsWeek)
    {
        //
    }
}
