<?php

namespace App\Http\Controllers;

use App\AdvertisementType;
use Illuminate\Http\Request;

class AdvertisementTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertisementType $advertisementType)
    {
        //
    }
}
