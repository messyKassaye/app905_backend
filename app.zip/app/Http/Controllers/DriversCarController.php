<?php

namespace App\Http\Controllers;

use App\DriversCar;
use Illuminate\Http\Request;

class DriversCarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DriversCar  $driversCar
     * @return \Illuminate\Http\Response
     */
    public function show(DriversCar $driversCar)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DriversCar  $driversCar
     * @return \Illuminate\Http\Response
     */
    public function edit(DriversCar $driversCar)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DriversCar  $driversCar
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, DriversCar $driversCar)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DriversCar  $driversCar
     * @return \Illuminate\Http\Response
     */
    public function destroy(DriversCar $driversCar)
    {
        //
    }
}
