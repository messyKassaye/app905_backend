<?php

namespace App\Http\Controllers;

use App\TabletPromotionBank;
use Illuminate\Http\Request;

class TabletPromotionBankController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\TabletPromotionBank  $tabletPromotionBank
     * @return \Illuminate\Http\Response
     */
    public function show(TabletPromotionBank $tabletPromotionBank)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\TabletPromotionBank  $tabletPromotionBank
     * @return \Illuminate\Http\Response
     */
    public function edit(TabletPromotionBank $tabletPromotionBank)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\TabletPromotionBank  $tabletPromotionBank
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TabletPromotionBank $tabletPromotionBank)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\TabletPromotionBank  $tabletPromotionBank
     * @return \Illuminate\Http\Response
     */
    public function destroy(TabletPromotionBank $tabletPromotionBank)
    {
        //
    }
}
