<?php

namespace App;

use App\Http\Resources\AdvertPaymentConfirmResource;
use Illuminate\Database\Eloquent\Model;

class Advert extends Model
{
    //



    public function advertMediaType(){
        return $this->belongsTo(AdvertisementMediaType::class,'advertisement_media_type_id');
    }

    public function views(){
            return $this->hasMany(CarAdvert::class);
    }

    public function places(){
        return $this->belongsToMany(Place::class);
    }

    public function car(){
        return $this->belongsToMany(Car::class);
    }

    public function carAdvert(){
        return $this->hasMany(CarAdvert::class);
    }

    public function company(){
        return $this->belongsTo(Company::class,'company_id');
    }

    public function paymentStatus(){
        return $this->hasOne(AdvertPaymentTransaction::class);
    }

    public function advertDeposit(){
        return $this->hasOne(AdvertDeposit::class);
    }

    public function deposit(){
        return $this->hasMany(Deposit::class);
    }

}
