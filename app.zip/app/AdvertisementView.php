<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertisementView extends Model
{
    //

    public function advert(){
        return $this->belongsTo(Advert::class);
    }

    public function car(){
        return $this->belongsTo(Car::class,'car_id');
    }

}
