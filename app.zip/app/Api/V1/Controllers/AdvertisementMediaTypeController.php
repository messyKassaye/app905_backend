<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\AdvertisementMediaType;
use App\Http\Resources\AdvertisementMediaResource;
use App\Http\Resources\AdvertisementMediaTypeResource;
use Illuminate\Http\Request;

class AdvertisementMediaTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $advertismentMedia = AdvertisementMediaType::all();
        return  AdvertisementMediaTypeResource::collection($advertismentMedia);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $advertMediaType = new AdvertisementMediaType();
        $advertMediaType->name = $request->name;
        $advertMediaType->per_view_payment=$request->per_view_payment;
        $advertMediaType->currency_id = $request->currency_id;
        $advertMediaType->description=$request->description;
        if($advertMediaType->save()){
            return response()->json(['status'=>true,'message'=>'Advertisement media saved successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'Something is not Good ):']);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertisementMediaType  $advertisementMediaType
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertisementMediaType $advertisementMediaType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertisementMediaType  $advertisementMediaType
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertisementMediaType $advertisementMediaType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertisementMediaType  $advertisementMediaType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $advertMedia = AdvertisementMediaType::find($id);
        $advertMedia->name = $request->name;
        $advertMedia->currency_id=$request->currency_id;
        $advertMedia->per_view_payment=$request->per_view_payment;
        $advertMedia->description=$request->description;
        if($advertMedia->save()){
            return response()->json(['status'=>true,'message'=>'Media update successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'Something is not Good):']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertisementMediaType  $advertisementMediaType
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(AdvertisementMediaType::destroy($id)){
            return response()->json(['status'=>true,'message'=>'Media deleted successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'Something is not Good): please try later']);
        }
    }
}
