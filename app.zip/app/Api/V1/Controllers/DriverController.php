<?php

namespace App\Api\V1\Controllers;

use App\Driver;
use App\DriversCar;
use Illuminate\Http\Request;

class DriverController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $driver = new Driver();
        $driver->user_id = $request->user_id;
        $driver->plate_number = $request->plate_number;
        $driver->save();

        // Convert cars JSON string to Array
        
        $cars_data = json_decode($request->car, true);
        foreach ($cars_data as $key => $json) {

            $driver_car = new DriversCar();
            $driver_car->parent_id = $json['parent_id'];
            $driver_car->name = $json['name'];
            $driver->car()->save($driver_car);
        }
        return response()->json(['status'=>true,'message'=>'Data is save Successfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Driver  $driver
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    { }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Driver  $driver
     * @return \Illuminate\Http\Response
     */
    public function edit(Driver $driver)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Driver  $driver
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Driver $driver)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Driver  $driver
     * @return \Illuminate\Http\Response
     */
    public function destroy(Driver $driver)
    {
        //
    }
}
