<?php

namespace App\Api\V1\Controllers;

use App\AdvertDownload;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Auth;
class AdvertDownloadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $workPlace = $request->car_work_place;

        if ($workPlace==null){
            return response()->json(['status'=>false,'status_type'=>'car work place not set','message'=>'Your car address is not set.']);

        }else{
            $downloadedAdverts = json_decode($request->downloadedAdverts);

            if($downloadedAdverts==null){

                $adverts = DB::table('advert_place')->whereIn('place_id',[1,$workPlace])
                    ->join('adverts',function ($join){
                        $join->on('advert_place.advert_id','=','adverts.id');
                    })->where('adverts.status','on_advert')->get();
                if (count($adverts)<=0){
                    return response()->json(['status'=>false,
                        'status_type'=>'no advert',
                        'message'=>'Sorry, there is no new advert you got to downloaded']);
                }else{
                    return response()->json(['status'=>true,'adverts'=>$adverts]);
                }

            }else{
                $adverts = DB::table('advert_place')->whereIn('place_id',[1,$workPlace])
                    ->join('adverts',function ($join){
                        $join->on('advert_place.advert_id','=','adverts.id');
                    })->where('adverts.status','on_advert')
                    ->whereNotIn('id',$downloadedAdverts)->get();

                if (count($adverts)<=0){
                    return response()->json(['status'=>false,
                        'status_type'=>'no advert',
                        'message'=>'Sorry, there is no new advert you got to downloaded']);
                }else{
                    return response()->json(['status'=>true,'adverts'=>$adverts]);
                }

            }

        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertDownload  $advertDownload
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertDownload $advertDownload)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertDownload  $advertDownload
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertDownload $advertDownload)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertDownload  $advertDownload
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdvertDownload $advertDownload)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertDownload  $advertDownload
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertDownload $advertDownload)
    {
        //
    }
}
