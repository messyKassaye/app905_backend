<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\Api\V1\Services\NotificationService;
use App\Api\V1\Services\SMSSenderService;
use App\Api\V1\Services\TabAdvertDepositService;
use App\Company;
use App\EntityType;
use App\Http\Resources\AdminAdvertResource;
use App\Notification;
use App\PaymentPercentage;
use Auth;
use Illuminate\Http\Request;

class AdminAdvertsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    protected $depositService,$notificationService,$SMSSender;

    public function __construct(TabAdvertDepositService $depositService,
                                NotificationService $notificationService,
                                SMSSenderService $SMSSenderService)
    {
        $this->depositService = $depositService;
        $this->notificationService = $notificationService;
        $this->SMSSender = $SMSSenderService;
    }


    public function index()
    {
        //
        $advert = Advert::all();
        return AdminAdvertResource::collection($advert);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $advert = Advert::where('id',$id)->with('carAdvert')->get();
        return response()->json(['data'=>$advert]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        //sometimes accidentally we approve adverts payment. then we have to cancel it
        $advert = Advert::find($id);
        $user = Company::find($advert->company->id)->user;
        if (strtolower($request->status) === 'cancel') {

            $advert->status = 'on_progress';
            if ($advert->save()) {
                $this->depositService->
                cancelAdvertDeposit($id);

                return response()->json(['status' => true, 'message' => 'Advert is Canceled successfully']);
            }

        } else if (strtolower($request->status) === 'on_advert' && strtolower($advert->status) !== 'on_advert') { //if there is no canceling
            $advert->status = $request->status;
            $advert->save();

            /* after updating advert classify the payment for tab advert and
               for drivers using their percentage payment */

            //Gulo advert payment percentage
            $totalAdvertPayment = $advert->required_views_number * $advert->advertMediaType->per_view_payment;

            $this->depositService->
            advertDeposit(Auth::guard()->user()->id,$id,$advert->paymentStatus->id ,$totalAdvertPayment);


            //send notification for advertiser that his advert is on air
            $message = 'Hello, '.$user->first_name.' Your advert media for product of '.$advert->product_name.' is approved and moved to download cloud. Now cars will download it and start advertising your product';

            $this->notificationService->notify(4,$advert->company->user_id,Auth::user()->id,$message,'advert/'.$advert->id);
            $this->SMSSender->send($user->phone,$message);

            return response()->json(['status' => true, 'message' => 'Advert updated successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'This advert is already on advert status.']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if (Advert::destroy($id)) {
            return response()->json(['status' => true, 'message' => 'Advert is deleted successfully']);
        } else {
            return response()->json(['status' => false, 'message' => 'Something is not Good ):']);
        }
    }
}
