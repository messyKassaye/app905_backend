<?php

namespace App\Api\V1\Controllers;

use App\AdvertisementType;
use App\Http\Resources\AdvertisementTypeResource;
use Illuminate\Http\Request;

class AdvertisementTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //

        $advertisement = AdvertisementType::all();
        if($advertisement!==null){
            return AdvertisementTypeResource::collection($advertisement);
        }
        return response()->json(['status'=>false,'message'=>'Data is not found']);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $advertisement = new AdvertisementType();
        $advertisement->name = $request->name;
        if($advertisement->save()){
            return response()->json(['status'=>true,'message'=>'Advertisement is saved successfully']);
        }
        return response()->json(['status'=>false,'message'=>'Advertisement is not saved successfully']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdvertisementType $advertisementType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertisementType  $advertisementType
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertisementType $advertisementType)
    {
        //
    }
}
