<?php

namespace App\Api\V1\Controllers;

use App\Api\V1\Services\SMSSenderService;
use App\Bank;
use App\Http\Resources\WithdrawalResource;
use App\Withdrawal;
use Illuminate\Http\Request;

class AdminWithdrawalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $sms;

    public function __construct(SMSSenderService $SMSSenderService)
    {
        $this->sms = $SMSSenderService;
    }

    public function index()
    {
        //
        $withdrawals = Withdrawal::all();
        return WithdrawalResource::collection($withdrawals);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $withdrawals = Withdrawal::find($id);
        $withdrawals->status = $request->status;
        if ($withdrawals->save()) {
            $message = 'Hello,' . $withdrawals->users->first_name . '. \nWe were processing your withdrawal request until now .
            Now we have send the ' . $withdrawals->amount . ' ETB to ' .
                Bank::find($withdrawals->bank->bank_id)->bank_name . ' as you requested \nThank you Gulo ads group';
            $this->sms->send($withdrawals->user->phone,$message);
            return response()->json(['status' => true, 'message' => 'Payment is done']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
