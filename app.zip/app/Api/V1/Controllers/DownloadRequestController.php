<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\Api\V1\Services\FileZipperService;
use App\DownloadRequest;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;

class DownloadRequestController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $fileZipperService;
    public function __construct(FileZipperService $fileZipperService)
    {
        $this->fileZipperService = $fileZipperService;
    }

    public function index()
    {
        //
        $userId = Auth::guard()->user()->id;
        $downloadRequest = DownloadRequest::where('user_id','=',$userId)->get();
        return response()->json(['status'=>true,'data'=>$downloadRequest]);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $userId = Auth::guard()->user()->id;
        $downloadRequest = DownloadRequest::where(
            ['user_id'=>$userId,'status'=>'new_request','device_id'=>$request->device_id])->get();
        if (count($downloadRequest)>0){
            return  response()->json([
                'status'=>true,
                'message'=>'Your order has been submitted successfully. But our kitchen is full of order. It will take 5-10 minutes to deliver your order could you wait us a little beat please. Thank you'
            ]);
        }else{
            $downloadRequest = new DownloadRequest();
            $downloadRequest->downloaded_adverts = $request->downloadedAdverts;
            $downloadRequest->device_id = $request->device_id;

            Auth::guard()->user()->downloadRequest()->save($downloadRequest);
            return  response()->json([
                'status'=>true,
                'message'=>'Your order has been submitted successfully. But our kitchen is full of order. It will take 5-10 minutes to deliver your order could you wait us a little bit please. Thank you'
            ]);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\DownloadRequest  $downloadRequest
     * @return \Illuminate\Http\Response
     */
    public function show($device_id,$status)
    {
        //
        $userId = Auth::guard()->user()->id;
        $downloadRequest = DownloadRequest::where([
            'user_id'=>$userId,
            'device_id'=>$device_id,
            'status'=>$status
        ])->get();
        return response()->json(['status'=>true,'data'=>$downloadRequest]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\DownloadRequest  $downloadRequest
     * @return \Illuminate\Http\Response
     */
    public function edit(DownloadRequest $downloadRequest)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\DownloadRequest  $downloadRequest
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        //
        $downloadRequest = DownloadRequest::find($id);
        $downloadRequest->status = 'downloaded';
        if ($downloadRequest->save()){
            $this->fileZipperService->deleteZippedFile($downloadRequest->file_name);
            return response()->json(['status'=>true,'message'=>"Update successfully"]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\DownloadRequest  $downloadRequest
     * @return \Illuminate\Http\Response
     */
    public function destroy(DownloadRequest $downloadRequest)
    {
        //
    }
}
