<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\Http\Resources\AdvertsResource;
use Illuminate\Http\Request;

class AdvertController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $adverts = Advert::all();
        return  AdvertsResource::collection($adverts);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $advert = new Advert();
        $advert->company_id = $request->company_id;
        $advert->advertisement_media_type_id = $request->advertisement_media_id;
        $advert->product_name = $request->product_name;
        $advert->required_views_number = $request->required_views_number;
        $advert->media_path = "not_assigned";
        if($advert->save()){
            $advert_places = json_decode($request->advert_places);
            $advert->places()->sync($advert_places);

            return  response()->json([
                'status'=>true,
                'message'=>'Advert is store successfully',
                'data'=>new AdvertsResource($advert)]);
        }else{
            return  response()->json(['status'=>false,'message'=>'Data is not save successfully']);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Advert  $advert
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $advert = Advert::find($id);
        if($advert){
            return  response()->json([
                'status'=>true,
                'data'=>new AdvertsResource($advert)
            ]);
        }else{
            return  response()->json(['status'=>false,'message'=>'Nothing is found by this id']);
        }

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Advert  $advert
     * @return \Illuminate\Http\Response
     */
    public function edit(Advert $advert)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Advert  $advert
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Advert  $advert
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Advert::destroy($id)){
            return response()->json(['status'=>true,'message'=>'Successfully deleted']);
        }else{
            return response()->json(['status'=>false,'message'=>'Not deleted']);
        }
    }
}
