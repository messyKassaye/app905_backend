<?php

namespace App\Api\V1\Controllers;

use App\Http\Resources\TabletResource;
use App\Tablet;
use Illuminate\Http\Request;
use Auth;
class TabletController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $tabletRegistration =Tablet::where('serial_number',$request->serial_number)->get();
        if(count($tabletRegistration)<=0){
            $tablet = new Tablet();
            $tablet->serial_number =$request->serial_number;
            $tablet->car_id = $request->car_id;
            $tablet->user_id = Auth::guard()->user()->id;
            if($tablet->save()){
                return response()->json(['status'=>true,'message'=>'This tablet is assigned successfully','tablet'=>$tablet]);
            }
        }else{
            return  response()->json(['status'=>false,'message'=>'This tablet is assigned for car']);
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Tablet  $tablet
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $tablet = Tablet::where('serial_number',$id)->get();
        return TabletResource::collection($tablet);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Tablet  $tablet
     * @return \Illuminate\Http\Response
     */
    public function edit(Tablet $tablet)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Tablet  $tablet
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tablet $tablet)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Tablet  $tablet
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tablet $tablet)
    {
        //
    }
}
