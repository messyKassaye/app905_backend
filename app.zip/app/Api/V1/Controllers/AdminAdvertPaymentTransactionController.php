<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\AdvertPaymentTransaction;
use App\Api\V1\Services\NotificationService;
use App\Api\V1\Services\SMSSenderService;
use App\Company;
use Illuminate\Http\Request;
use Auth;
class AdminAdvertPaymentTransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $notification,$SMSSender;
    public function __construct(NotificationService $notificationService,SMSSenderService $SMSSenderService)
    {
        $this->notification = $notificationService;
        $this->SMSSender = $SMSSenderService;
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $paymentTransaction = AdvertPaymentTransaction::find($id);
        if($paymentTransaction) {
            $advert = Advert::find($paymentTransaction->advert_id);
            $user = Company::find($advert->company->id)->user;
            $paymentTransaction->approved_by = Auth::guard()->user()->id;
            $paymentTransaction->save();
            $message = 'We were processing your advert payment for ' . $advert->product_name . ' product until now.' .
                ' And we found that your payment is correct and we release your product on 
                advertisement Air of our platform starting now on. Upload your media now and get more income.';
            $this->notification->notify(3, $advert->company->user_id, Auth::user()->id, $message, 'advert/' . $advert->id);
            $this->SMSSender->send($user->phone,$message);

            return response()->json(['status' => true, 'message' => 'Advert updated successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'There no payment transaction by this id']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
