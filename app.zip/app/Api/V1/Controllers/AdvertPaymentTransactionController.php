<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\AdvertPaymentTransaction;
use App\Api\V1\Services\NotificationService;
use App\Http\Resources\AdvertisementMediaResource;
use App\Http\Resources\AdvertPaymentConfirmResource;
use Illuminate\Http\Request;
use Auth;
class AdvertPaymentTransactionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $notification;

    public function __construct(NotificationService $notificationService)
    {
        $this->notification = $notificationService;
    }

    public function index()
    {
        //

        echo 'Hello';
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $payment = new AdvertPaymentTransaction();
        $payment->bank_id = $request->bank_id;
        $payment->advert_id = $request->advert_id;
        $payment->deposited_by_name=$request->deposited_by_name;
        $payment->transaction_ref_number=$request->transaction_ref_number;
        $payment->transaction_date=$request->transaction_date;
        $payment->receipt_image = $request->receipt_image;
        if($payment->save()){
            $message = 'New advert payment is sent to you from '.$request->deposited_by_name.'. And it is waiting your decision';
            $this->notification->notify(1,1,1,$message,'advert/'.$request->advert_id);

            return response(['status'=>true,'message'=>'Thank you for being our customer. We will validate your payment and announce you after one day',
                'data'=>$payment]);
        }else{
            return  response()->json(['status'=>false,'message'=>'Data is saved successfully']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertPaymentTransaction  $advertPaymentTransaction
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertPaymentTransaction $advertPaymentTransaction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertPaymentTransaction  $advertPaymentTransaction
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertPaymentTransaction $advertPaymentTransaction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertPaymentTransaction  $advertPaymentTransaction
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertPaymentTransaction  $advertPaymentTransaction
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertPaymentTransaction $advertPaymentTransaction)
    {
        //
    }
}
