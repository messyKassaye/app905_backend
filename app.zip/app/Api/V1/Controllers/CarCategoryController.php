<?php

namespace App\Api\V1\Controllers;

use App\CarCategory;
use App\Http\Resources\CarCategoryResource;
use Illuminate\Http\Request;

class CarCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $cars = CarCategory::where('parent_id',0)->get();
        return  CarCategoryResource::collection($cars);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CarCategory  $carCategory
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $cars = CarCategory::where('parent_id',$id)->get();
        return CarCategoryResource::collection($cars);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CarCategory  $carCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(CarCategory $carCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CarCategory  $carCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CarCategory $carCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CarCategory  $carCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarCategory $carCategory)
    {
        //
    }
}
