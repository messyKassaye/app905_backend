<?php

namespace App\Api\V1\Controllers;

use App\Api\V1\Services\FileSizeService;
use App\Api\V1\Services\FileZipperService;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Auth;
use ZipArchive;

class FileHandlingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $fileZipperService;

    public function __construct(FileZipperService $fileZipperService)
    {
        $this->fileZipperService = $fileZipperService;
    }

    public function index()
    {
        //
        return $this->fileSizeService->handleFile();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $user = User::find(Auth::guard()->user()->id);
        $public_path = public_path();

        if(is_dir($public_path.'/Zips')==false){
            mkdir($public_path.'/Zips');
            mkdir($public_path.'/Zips/files');
        }

        //check if drivers cars and downloader  have  set their address
        if(count($user->place)>0){

            //first time downloader for drivers and for all downloader
            if ($request->downloadedAdverts==null){
                $adverts = DB::table('advert_place')->whereIn('place_id',[1,$user->place[0]['id']])->join('adverts',function ($join){
                    $join->on('advert_place.advert_id','=','adverts.id');
                })->where('adverts.status','on_advert')->select('adverts.file_name','adverts.id')->get();
                return $this->prepareFile($user,$public_path,$adverts);
            }else{
                //if drivers have downloaded adverts before and if they need new adverts
                $downloadedAdverts = json_decode($request->downloadedAdverts);
                $adverts = DB::table('advert_place')->whereIn('place_id',[1,$user->place[0]['id']])->join('adverts',function ($join){
                    $join->on('advert_place.advert_id','=','adverts.id');
                })->where('adverts.status','on_advert')
                    ->whereNotIn('id',$downloadedAdverts)->select('adverts.file_name','adverts.id')->get();

                if(count($adverts)<=0){
                    return response()->json(['status'=>false,'message'=>'No new advert is registered until now']);
                }else{
                    return $this->prepareFile($user,$public_path,$adverts);
                }

            }

        }else{
            return response()->json(['status'=>false,'message'=>'You are not set your address/location. Please set your location and start downloading your file now']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /*public function prepareFile($user,$public_path,$adverts){
        $previousZipFIle = count($this->fileZipperService->findZippedFile($user->id));

        $today = Carbon::now()->format('dmyhis');
        $text_file_name = $user->first_name.$today;
        fopen($public_path.'/Zips/files/'.$text_file_name.'.json','w');
        $textFilePath = $public_path.'/Zips/files/'.$text_file_name.'.json';

        $zip = new ZipArchive;
        $user = User::find(Auth::guard()->user()->id);

        $userInfo = array(
            "id"=>$user->id,
            "date"=>$today
        );
        $users = $userInfo;

        $mainArray = array();
        $mainArray['userInfo'] =$users;

        $advertsData = array();

        $zipName = $user->first_name.$today.'.zip';
        if ($previousZipFIle<=0){
            $this->fileZipperService->saveZippedFile($user->id,$zipName);
        }else{
            $this->fileZipperService->updateZippedFile($user->id,$zipName);
        }
        foreach (json_decode($adverts,true) as $adv){
            $advertsData[] = array(
                'id'=>$adv['id'],
                'maximumViewPerDay'=>'5',
                'privilege'=>'High',
                'fileName' =>$adv['file_name']
            );
            $mainArray['advertData'] = $advertsData;
            $this->fileZipperService->userInfo($textFilePath,$mainArray);
            if ($zip->open($public_path . '/Zips/'.$zipName, ZipArchive::CREATE) === TRUE) {
                $zip->addFile($public_path.'/uploads/'.$adv['file_name'], $adv['file_name']);
                $zip->addFile($public_path.'/Zips/files/'.$text_file_name.'.json',$text_file_name.".json");
                $zip->close();
            } else {
                echo 'failed';
            }
        }

        return response()->json(['status'=>true,'file_path'=>$zipName]);}*/

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
