<?php

namespace App\Api\V1\Controllers;

use App\Company;
use App\Http\Resources\CompanyResource;
use Illuminate\Http\Request;

class AdminCompanyController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $companies = Company::all();
        return CompanyResource::collection($companies);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $company = new Company();
        $company->user_id =Auth::guard()->user()->id;
        $company->name = $request->name;
        $company->phone=$request->phone;
        $company->website = $request->website;
        if($company->save()){
            return response()->json(['status'=>true,'message'=>'Company is registered successfully',
                'data'=>new CompanyResource($company)]);
        }
        return response()->json(['status'=>false,'message'=>'Company is not saved successfully']);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $company = Company::find($id);
        $company->name = $request->name;
        $company->phone = $request->phone;
        $company->website = $request->website;
        if($company->save()){
            return response()->json(['status'=>true,'message'=>'Company is updated successfully','data'=>$company]);
        }else{
            return response()->json(['status'=>false,'message'=>'Something is not Good ):']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
