<?php

namespace App\Api\V1\Controllers;

use App\Bank;
use App\Http\Resources\BankResource;
use Illuminate\Http\Request;

class BankController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $banks = Bank::all();
        return BankResource::collection($banks);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $banks = Bank::all();
        $isFound = false;
        $percentage = 0.0;
        foreach ($banks as $bank){
            similar_text($bank['bank_name'], $request->bank_name, $percentage);
        }

        if($percentage>75.0){
            return  response(['status'=>false,'message'=>$request->bank_name.' is Already registered']);
        }else{
            $bank  = new Bank();
            $bank->bank_name = $request->bank_name;
            $bank->abbreviation = $request->abbreviation;
            $bank->logo_path=$request->logo_path;
            if($bank->save()){
                return  response()->json(['status'=>true,'message'=>'Bank is saved successfully','data'=>$bank]);
            }
            return  response()->json(['status'=>false,'message'=>'Bank is not saved. something is not Good ):']);
        }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function show(Bank $bank)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function edit(Bank $bank)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $bank = Bank::find($id);
        $bank->bank_name = $request->bank_name;
        $bank->abbreviation = $request->abbreviation;
        $bank->logo_Path=$request->logo_path;
        if($bank->save()){
            return response()->json(['status'=>true,'message'=>'Bank is updated successfully','data'=>$bank]);
        }else{
            return response()->json(['status'=>false,'message'=>'Something is not Good):']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bank  $bank
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if (Bank::destroy($id)){
            return  response()->json(['status'=>true,'message'=>'Bank is deleted successfully']);
        }
        return response()->json(['status'=>false,'message'=>'Something is not Good):']);

    }
}
