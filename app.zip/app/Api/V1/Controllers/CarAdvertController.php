<?php

namespace App\Api\V1\Controllers;
use App\CarAdvert;
use App\Http\Resources\AdminCarAdvertResource;
use App\Week;
use Illuminate\Http\Request;
use Auth;
class CarAdvertController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $carAdvert = CarAdvert::all();
        return  AdminCarAdvertResource::collection($carAdvert);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {


        $cardAdvert = new CarAdvert();
        $cardAdvert->car_id = $request->car_id;
        $cardAdvert->advert_id = $request->advert_id;
        $cardAdvert->advert_time = $request->advert_time;
        $cardAdvert->picture = $request->picture;
        $cardAdvert->number_of_viewers =$request->number_of_viewers;
        $cardAdvert->save();
        return response()->json(['status'=>true,'car_id'=>$request->car_id,'message'=>'Saved successfully']);

        /*$advertsViews = json_decode($request->data,true);
        foreach ($advertsViews as $views){
            $cardAdvert = new CarAdvert();
            $cardAdvert->car_id = $views['car_id'];
            $cardAdvert->advert_id = $views['advert_id'];
            $cardAdvert->advert_time = $views['advert_time'];
            $cardAdvert->picture = $views['picture'];
            $cardAdvert->number_of_viewers =$views['number_of_viewers'];
            $cardAdvert->save();
        }
        return response()->json(['status'=>true,'message'=>'Advert viewed saved successfully']);*/

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CarAdvert  $carAdvert
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $carAdvert = CarAdvert::where(['advert_id'=>$id])
            ->with('car')->with('car.workingPlace')->with('checker')->simplePaginate(15);
        return $carAdvert;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CarAdvert  $carAdvert
     * @return \Illuminate\Http\Response
     */
    public function edit(CarAdvert $carAdvert)
    {
        //
    }

    public function approveAdvert($id){
        $carAdvert = CarAdvert::where(['advert_id'=>$id,'status'=>'Payed'])
            ->with('car')->with('car.workingPlace')->with('checker')->simplePaginate(15);
        return $carAdvert;
    }

    public function fakeAdvert($id){
        $carAdvert = CarAdvert::where(['advert_id'=>$id,'status'=>'not_real_advert'])
            ->with('car')->with('car.workingPlace')->with('checker')->simplePaginate(15);
        return $carAdvert;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CarAdvert  $carAdvert
     * @recls
     * turn \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        //

        $carAdvert = CarAdvert::find($id);
        $carAdvert->status = $request->status;
        if ($carAdvert->save()){
            return response()->json(['status'=>true,'message'=>'Convert to unpaid advert']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CarAdvert  $carAdvert
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarAdvert $carAdvert)
    {
        //
    }
}
