<?php

namespace App\Api\V1\Controllers;

use App\Api\V1\Services\FileSizeService;
use Illuminate\Http\Request;
use Auth;
class ZipFileDownloader extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
       /* //
        $fileName = public_path().'/Zips/Ezedin130220.zip';
        $header = array(
            'Content-Type: application/zip'
        );
       return response()->download($fileName,'download.zip',$header);*/
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function download($fileNames){
        $fileName = $fileNames.'.zip';
        $header = array(
            "Content-Type: application/zip",
            "Content-Transfer-Encoding: Binary",
            "Content-Length:".filesize(public_path().'/Zips/'.$fileName),
            "Content-Disposition: attachment; filename=".$fileName
        );
        return response()->download(public_path().'/Zips/'.$fileName,$fileName,$header);
    }
    public function show($file)
    {
        //

        $fileName = public_path().'/Zips/'.$file;
        $header = array(
            'Content-Type: application/zip'
        );
        return response()->download($fileName,$fileName,$header);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $filePath = public_path().'/Zips/'.$id;
        $fileName = $id;
        $header = array(
            'Content-Type: application/zip',
            "Content-Disposition: attachment; filename=".$filePath,
            "Content-Length: " . filesize($filePath)
        );
        $response = \Response::download($filePath,$fileName,$header);
        ob_end_clean();

        return $response;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
