<?php

namespace App\Api\V1\Controllers;

use App\CarAdvert;
use App\User;
use Illuminate\Http\Request;

class CarAdvertViewChecker extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $carAdvert = CarAdvert::where(['advert_id'=>$id,'status'=>'On progress'])
            ->with('car')->with('car.workingPlace')->with('checker')->simplePaginate(15);
        return $carAdvert;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $carAdverts = CarAdvert::find($id);
        if($carAdverts){
            $carAdverts->status = $request->status;
            $carAdverts->checker()->sync(User::find(Auth::guard()->user()->id));
            if($carAdverts->save()){
                return response()->json(['status'=>true,'message'=>'Car advert is updated']);
            }
        }else{
            return response()->json(['status'=>false,'message'=>'No data in this id']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
