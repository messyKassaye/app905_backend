<?php

namespace App\Api\V1\Controllers;

use App\Http\Resources\PaymentResource;
use App\Payment;
use Auth;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $payment = Auth::guard()->user()->payments;
        if(count($payment)>0){
         return response()->json(['status'=>true,'message'=>'your data','data'=>PaymentResource::collection($payment)]);
        }else{
            return response()->json(['status'=>false,'message'=>'You do not have any payment','data'=>[]]);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $payment = new Payment();
        $payment->amount = $request->amount;
        $payment->description = $request->description;
        $payment->payment_type = $request->payment_type;
        $user = Auth::guard()->user();
        if($user->payments()->save($payment)){
            return response(['status'=>true,'message'=>'Payment is done successfully','data'=>new PaymentResource($payment)]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function show(Payment $payment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function edit(Payment $payment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Payment $payment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Payment  $payment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Payment $payment)
    {
        //
    }
}
