<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use Illuminate\Http\Request;

class TopCounterController extends Controller
{
    //

    public function topAdvertedCompany(){
        $advert = Advert::where('required_views_number','>','0')
            ->where('media_path','!=',null)->with('company')->get();
        return $advert;
    }
}
