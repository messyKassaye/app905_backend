<?php

namespace App\Api\V1\Controllers;

use App\GlobalRideAdsViewer;
use Carbon\Carbon;
use Illuminate\Http\Request;

class GlobalRideAdsViewerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $global = GlobalRideAdsViewer::all();
        return count($global);

    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $global= new GlobalRideAdsViewer();
        $global->user_id = $request->identity_id;
        $global->time = Carbon::now();
        $global->device_type = $request->device_type;
        $global->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\GlobalRideAdsViewer  $globalRideAdsViewer
     * @return \Illuminate\Http\Response
     */
    public function show(GlobalRideAdsViewer $globalRideAdsViewer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\GlobalRideAdsViewer  $globalRideAdsViewer
     * @return \Illuminate\Http\Response
     */
    public function edit(GlobalRideAdsViewer $globalRideAdsViewer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\GlobalRideAdsViewer  $globalRideAdsViewer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, GlobalRideAdsViewer $globalRideAdsViewer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\GlobalRideAdsViewer  $globalRideAdsViewer
     * @return \Illuminate\Http\Response
     */
    public function destroy(GlobalRideAdsViewer $globalRideAdsViewer)
    {
        //
    }
}
