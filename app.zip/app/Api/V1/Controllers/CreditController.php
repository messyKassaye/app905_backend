<?php

namespace App\Api\V1\Controllers;

use App\Credit;
use App\Finance;
use App\FinanceBalance;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Auth;
class CreditController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //payed from tab adverts account
        if(User::find($request->user_id)){
            $finance = new Finance();
            $finance->withdrawal = 0.0;
            $finance->withdrawal_time = null;
            $finance->credit = $request->amount;
            $finance->credit_time = Carbon::now();
            $finance->user_id = $request->user_id;
            $finance->financier_id = Auth::guard()->user()->id;
            if($finance->save()){
                //balance calculations
                $credit_identity=$request->credit_identity;
                if(strtolower($credit_identity)==='tab advert'){
                   return $this->tabAdvertsCredit($request);
                }else if(strtolower($credit_identity)==='driver'){
                 return $this->driverCredit($request);
                }else{
                    return response()->json(['status'=>false,'message'=>'There is no payment for this request']);
                }
            }else{
                return response()->json(['status'=>false,'message'=>'Something  is not Good ):']);
            }
        }else{
            return response()->json(['status'=>false,'message'=>'Go fuck yourself']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Credit  $credit
     * @return \Illuminate\Http\Response
     */
    public function tabAdvertsCredit(Request $request)
    {
        //
        $financeBalance = FinanceBalance::where('user_id',$request->user_id)->get();
        $totalBalance = $financeBalance[0]['balance'] + $request->amount;

        $financeBalanceUpdater = FinanceBalance::find($financeBalance[0]['id']);
        $financeBalanceUpdater->balance = $totalBalance;
        if($financeBalanceUpdater->save()){
            return response()->json(['status'=>true,'message'=>'Finance is saved successfully']);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Credit  $credit
     * @return \Illuminate\Http\Response
     */
    public function driverCredit(Request $request)
    {
        //tab adverts balance will be minimized and added to user balance
        $tabAdvertBalance = FinanceBalance::where('user_id',Auth::guard()->user()->id)->get();
        $tabAdvertTotalBalance = $tabAdvertBalance[0]['balance']-$request->amount;

        $tabAdvertFinanceBalance = FinanceBalance::find($tabAdvertBalance[0]['id']);
        $tabAdvertFinanceBalance->balance = $tabAdvertTotalBalance;
        if($tabAdvertFinanceBalance->save()){

            // user balance will be maximized here
            $financeBalance = FinanceBalance::where('user_id',$request->user_id)->get();
            $totalBalance = $financeBalance[0]['balance'] + $request->amount;

            $financeBalanceUpdater = FinanceBalance::find($financeBalance[0]['id']);
            $financeBalanceUpdater->balance = $totalBalance;
            $financeBalanceUpdater->save();
            return response()->json(['status'=>true,'message'=>'Driver is payed successfully']);
        }

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Credit  $credit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Credit $credit)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Credit  $credit
     * @return \Illuminate\Http\Response
     */
    public function destroy(Credit $credit)
    {
        //
    }
}
