<?php

namespace App\Api\V1\Controllers;

use App\Api\V1\Services\SMSSenderService;
use App\CarDriver;
use App\VehicleDriver;
use Illuminate\Http\Request;
use Auth;
use Illuminate\Support\Facades\DB;

class VehicleDriverController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    protected $SMSService;
    public function __construct(SMSSenderService $SMSSenderService)
    {
        $this->SMSService = $SMSSenderService;
    }

    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //

            $vehicleDriver = new VehicleDriver();
            $vehicleDriver->phone = $request->phone;
            $vehicleDriver->car_id = $request->car_id;
            $vehicleDriver->email = $request->email;
            $vehicleDriver->registered_by = Auth::guard()->user()->id;
            $verification_code = $this->generateCouponCode(6);
            $vehicleDriver->verification_code = $verification_code;
            if($vehicleDriver->save()){
                $smsMessage = "Hello,there How you doing today. \nYou have been registered as driver of".Auth::guard()->user()->first_name."'s car.
                Set your account for Gulo ads using below link\n".env('FRONT_HOST_NAME')."/driver_link/".$verification_code;
                //$this->SMSService->send($request->phone,$smsMessage);
                return response()->json(['status' => true, 'message' => 'Driver link created successfully']);
            }

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $driverLink = DB::table('vehicle_drivers')
            ->where(['verification_code'=>$id,'status'=>false])->get();
        if (count($driverLink)>0){
            return response()->json(['status'=>true,'message'=>'Correct link address is found']);
        }else{
            return response()->json(['status'=>false,'message'=>'You have sent incorrect driver link address.']);
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function edit(CarDriver $carDriver)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CarDriver $carDriver)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CarDriver  $carDriver
     * @return \Illuminate\Http\Response
     */
    public function destroy(CarDriver $carDriver)
    {
        //
    }

   public function generateCouponCode($length = 4)
    {
        $chars = '0123456789';
        $ret = '';
        for ($i = 0; $i < $length; ++$i) {
            $random = str_shuffle($chars);
            $ret .= $random[0];
        }
        return $ret;
    }
}
