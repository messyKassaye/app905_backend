<?php

namespace App\Api\V1\Controllers;

use App\Car;
use App\FinanceBalance;
use App\Role;
use App\User;
use App\VehicleDriver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Tymon\JWTAuth\JWTAuth;
use Auth;
class DriverSignup extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function signUp(Request $request,JWTAuth $JWTAuth)
    {
        //
        $driverLink = $driverLink = DB::table('vehicle_drivers')
            ->where('verification_code',$request->verification_code)->get();
        $user = new User();
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->password = $request->password;
        $user->email = $driverLink[0]->email;
        $user->phone = $driverLink[0]->phone;
        $user->avator = 'letter';
        $user->confirmation_code = $this->generateCouponCode(6);
        if ($user->save()){
            //update link
            $driverLinkUpdate = VehicleDriver::find($driverLink[0]->id);
            $driverLinkUpdate->status=true;
            $driverLinkUpdate->save();

            //update car driver id
            $car = Car::find($driverLink[0]->car_id);
            $car->driver_id = $user->id;
            $car->save();


            $role = Role::find(4);
            $user->role()->sync($role);

            $financeBalance = new FinanceBalance();
            $financeBalance->balance = 0.0;
            $user->balance()->save($financeBalance);

            $credentials = ['email'=>$driverLink[0]->email,'password'=>$request->password];
            $token = Auth::guard()->attempt($credentials);
            $role_id = User::find(Auth::guard()->user()->id)->role[0];
            return response()->json([
                'status' => true,
                'role'=>$role_id,
                'token' => $token
            ], 201);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    function generateCouponCode($length = 4)
    {
        $chars = '0123456789';
        $ret = '';
        for ($i = 0; $i < $length; ++$i) {
            $random = str_shuffle($chars);
            $ret .= $random[0];
        }
        return $ret;
    }
}
