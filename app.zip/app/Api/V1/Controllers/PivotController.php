<?php

namespace App\Api\V1\Controllers;

use Illuminate\Http\Request;
use Auth;
class PivotController extends Controller
{
    //

    public function pivot(Request $request){
        if($request->type=='place'){
           if(Auth::guard()->user()->place()->sync($request->place_id)){
               return response()->json(['status'=>true,'message'=>'Updated successfully']);
           }
        }
    }
}
