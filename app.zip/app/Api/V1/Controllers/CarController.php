<?php

namespace App\Api\V1\Controllers;

use App\Car;
use App\Http\Resources\CarResource;
use App\Place;
use App\User;
use Illuminate\Http\Request;
use Auth;

class CarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $cars = Car::where('user_id',Auth::guard()->user()->id)->get();
        return  CarResource::collection($cars);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $plate_existence = Car::where('plate_number',$request->plate_number)->get();
        if(count($plate_existence)>0){
            return  response()->json(['status'=>false,'message'=>'This plate number is registered before']);
        }else{
            $user_id = Auth::guard()->user()->id;
            $car = new Car();
            $car->user_id = $user_id;
            $car->plate_number = $request->plate_number;
            if ($car->save()){
                $car->category()->sync($request->category_id);
                return  response()->json(['status'=>true,'message'=>'Car is saved successfully',
                    'car'=>$car]);
            }
        }


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function show(Car $car)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function edit(Car $car)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        //
        $car = Car::find($id);
        $car->plate_number = $request->plate_number;
        if ($car->save()){
            $place = Place::find($request->place_id);
            $car->workingPlace()->sync($place);

            $user = User::find($car->user_id);
            $user->place()->sync($place);

            return response()->json(['status'=>true,'message'=>'Car is update successfully']);
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Car  $car
     * @return \Illuminate\Http\Response
     */
    public function destroy(Car $car)
    {
        //
    }
}
