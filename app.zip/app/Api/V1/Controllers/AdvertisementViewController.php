<?php

namespace App\Api\V1\Controllers;

use App\Advert;
use App\AdvertisementView;
use App\Http\Resources\AdvertisementViewResource;
use App\Tablet;
use App\User;
use Illuminate\Http\Request;
use App\Http\Resources\AdvertViewsResource;
use Auth;


class AdvertisementViewController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $advertView = AdvertisementView::all();
        return AdvertViewsResource::collection($advertView);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $advertsViews = json_decode($request->data,true);
        foreach ($advertsViews as $views){
            $advertVIew = new AdvertisementView();
            $advertVIew->car_id = $views['car_id'];
            $advertVIew->advert_id = $views['advert_id'];
            $advertVIew->advert_time = $views['advert_time'];
            $advertVIew->picture = $views['picture'];
            $advertVIew->number_of_viewers =$views['number_of_viewers'];
            $advertVIew->save();

        }

        return response()->json(['status'=>true,'message'=>'Advert viewed saved successfully']);

    }

    public  function storeObject(Request $request){
        echo "hi";
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertisementView  $advertisementView
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $advert = AdvertisementView::where('advert_id',$id)->get();
        return AdvertisementViewResource::collection($advert);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertisementView  $advertisementView
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertisementView $advertisementView)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertisementView  $advertisementView
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $advertView = AdvertisementView::find($id);
        $advertView->advert_time = $request->advert_time;
        $advertView->picture = $request->picture;
        $advertView->status = $request->status;
        if ($advertView->save()){
            return response()->json(['status'=>true,'message'=>'Advert view updated successfully']);
        }else{
            return response()->json(['status'=>false,'message'=>'Advert view is not updated successfully']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertisementView  $advertisementView
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertisementView $advertisementView)
    {
        //
    }
}
