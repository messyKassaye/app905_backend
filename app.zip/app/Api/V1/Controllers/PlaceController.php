<?php

namespace App\Api\V1\Controllers;

use App\Http\Resources\PlaceResource;
use App\Place;
use Illuminate\Http\Request;

class PlaceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $places = Place::all();
        return PlaceResource::collection($places);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $place = new Place();
        $place->country = $request->country;
        $place->city = $request->city;
        $place->latitude = $request->latitude;
        $place->longtude = $request->longtude;
        if($place->save()){
            return response()->json(['status'=>true,'message'=>'Places is saved successfully']);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Place  $place
     * @return \Illuminate\Http\Response
     */
    public function show(Place $place)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Place  $place
     * @return \Illuminate\Http\Response
     */
    public function edit(Place $place)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Place  $place
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $place= Place::find($id);
        $place->country = $request->country;
        $place->city = $request->city;
        if($place->save()){
            return  response()->json(['status'=>true,'message'=>'Place is update successfully']);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Place  $place
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Place::destroy($id)){
            return response()->json(['status'=>true,'message'=>'Place deleted successfully']);
        }
    }
}
