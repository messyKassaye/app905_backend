<?php

namespace App\Api\V1\Controllers;

use App\AdvertViewPayment;
use App\Api\V1\Services\AdvertPaymentService;
use App\Api\V1\Services\PercentCalculator;
use App\CarAdvert;
use App\Http\Resources\AdvertsResource;
use App\Http\Resources\AdvertViewPaymentResource;
use App\PaymentPercentage;
use Illuminate\Http\Request;
use Auth;

class AdvertViewPaymentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        //
        $advertViewpayment = AdvertViewPayment::where('payed_for',
            Auth::guard()->user()->id)->get();
        return AdvertViewPaymentResource::collection($advertViewpayment);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //payment percentage

       /* $paymentPercentage = PaymentPercentage::find(1);
        $driverPayment = $paymentPercentage->drivers_percentage;
        $tabAdvertPayment = 100-$driverPayment;

        $carAdverts = CarAdvert::where('status','On progress')->get();
        foreach ($carAdverts as $adverts){
          return $this->pay(CarAdvert::find($adverts->id));
        }*/

       /* $carAdvert = CarAdvert::find($request->car_advert_id);
        if($carAdvert->status=='payed'){
            return response()->json(['status'=>false,'message'=>'This advert is already payed for who it deserved']);
        }else{
            $advert = new AdvertsResource($carAdvert->advert);
            $car = $carAdvert->car;

            $perViewPayment = $advert->advertMediaType->per_view_payment;
            $payerId = Auth::guard()->user()->id;
            $carAdvertId = $request->car_advert_id;

            //driver is payed
            $driverTotalPayment = $this->percentageCalculator->calculate($driverPayment,$perViewPayment);
            $driverResult = $this->advertViewPaymentService->driversPayment($car->user_id,$driverTotalPayment,$payerId,$carAdvertId);

            //tab advert is payed
            $tabAdvertTotalPayment = $this->percentageCalculator->calculate($tabAdvertPayment,$perViewPayment);
            $tabAdvertResult = $this->advertViewPaymentService->tabAdvertsPayment(1,$tabAdvertTotalPayment,$payerId,$carAdvertId);

            if($driverResult&&$tabAdvertResult){
                $carAdvert->status = 'Payed';
                $carAdvert->save();
                return response()->json(['status'=>true,'message'=>'Payed successfully']);
            }
        }*/

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\AdvertViewPayment  $advertViewPayment
     * @return \Illuminate\Http\Response
     */
    public function show(AdvertViewPayment $advertViewPayment)
    {
        //
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\AdvertViewPayment  $advertViewPayment
     * @return \Illuminate\Http\Response
     */
    public function edit(AdvertViewPayment $advertViewPayment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\AdvertViewPayment  $advertViewPayment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AdvertViewPayment $advertViewPayment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\AdvertViewPayment  $advertViewPayment
     * @return \Illuminate\Http\Response
     */
    public function destroy(AdvertViewPayment $advertViewPayment)
    {
        //
    }
}
