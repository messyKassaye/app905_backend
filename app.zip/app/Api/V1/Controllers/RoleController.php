<?php

namespace App\Api\V1\Controllers;

use App\Http\Resources\RoleResource;
use App\Role;
use Auth;
use Illuminate\Http\Request;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $roles = Role::where('is_public','=','1')->get();
        return $roles;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $role = new Role();
        $role->name = $request->name;
        $role->is_public = $request->is_public;
        if($role->save()){
            return response()->json(['status'=>true,'message'=>'Role is saved successfully','data'=>$role]);
        }
        return response()->json(['status'=>false,'message'=>'Something is not Good ):']);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function edit(Role $role)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request,$id)
    {
        //
        $role = Role::find($id);
        $role->name = $request->name;
        if($role->save()){
            return response()->json(['status'=>true,'message'=>'Role is updated successfully','data'=>$role]);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        if(Role::destroy($id)){
            return  response()->json(['status'=>true,'message'=>'Data is deleted successfully']);
        }
    }
}
