<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\AdvertisingEngineerSample;
class MediaType extends Model
{
    //

    public function advertisingEngineersample(){
        return $this->hasOne(AdvertisingEngineerSample::class);
    }
}
