<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
    //
    protected $fillable = ['id','name','is_public'];
    protected $visible = ['id','name','is_public'];

    public function user(){
        return $this->belongsToMany(User::class);
    }
}
