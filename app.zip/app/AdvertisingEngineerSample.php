<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\MediaType;
class AdvertisingEngineerSample extends Model
{
    //


    public function user(){
        return $this->belongsTo(User::class);
    }

    public function mediaType(){
        return $this->belongsTo(MediaType::class);
    }
}
