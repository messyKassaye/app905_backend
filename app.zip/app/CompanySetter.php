<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanySetter extends Model
{
    //
}
