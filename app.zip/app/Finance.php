<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\FinanceBalance;
class Finance extends Model
{
    //
    public function user(){
        return $this->belongsTo(User::class);
    }

}
