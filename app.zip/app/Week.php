<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Week extends Model
{
    //
    protected $visible = ['id','week_no'];

    public function carAdverts(){
        return $this->belongsToMany(CarAdvert::class,'caradvert_week');
    }

    public function payments(){
        return $this->belongsToMany(Payment::class);
    }
}
