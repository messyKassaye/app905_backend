<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Car extends Model
{


    public function user(){
        return $this->belongsToMany(User::class);
    }

    public function category(){
        return $this->belongsToMany(Category::class);
    }

    public function week(){
        return $this->hasOne(Week::class);
    }

    public function advert(){
        return $this->hasMany(CarAdvert::class);
    }

    public function driver(){
        return $this->belongsTo(User::class,'driver_id');
    }

    public function driverLink(){
        return $this->hasOne(VehicleDriver::class);
    }

    public function workingPlace(){
        return $this->belongsToMany(Place::class);
    }

    public function tablet(){
        return $this->hasMany(Tablet::class);
    }

    public function advertView(){
        return $this->hasMany(AdvertisementView::class);
    }

}
