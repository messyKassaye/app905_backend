<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class BankAccount extends Model
{
    //

    public function users(){
        return $this->belongsToMany(User::class);
    }

    public function banks(){
        return $this->belongsTo(Bank::class,'bank_id');
    }
}
