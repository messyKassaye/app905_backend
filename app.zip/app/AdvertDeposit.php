<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Advert;
use App\Deposit;
class AdvertDeposit extends Model
{
    //

    public function advert(){
        return $this->belongsTo(Advert::class);
    }

    public function deposits(){
        return $this->hasMany(Deposit::class,'advert_deposit_id');
    }
}
