<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarDriver extends Model
{
    //
}
