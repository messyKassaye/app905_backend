<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Currency;
class AdvertisementMediaType extends Model
{
    //
protected $visible = ['id','name','per_view_payment','currency'];
    public function advert(){
        return $this->hasMany(Advert::class);
    }

    public function currency(){
        return $this->belongsTo(Currency::class);
    }
}
