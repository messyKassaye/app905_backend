<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertComplain extends Model
{
    //
}
