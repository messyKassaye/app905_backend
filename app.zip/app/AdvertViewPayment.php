<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdvertViewPayment extends Model
{
    //

    public function carAdvert(){
        return $this->belongsTo(CarAdvert::class);
    }
}
