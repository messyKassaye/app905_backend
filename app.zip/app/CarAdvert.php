<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CarAdvert extends Model
{
    //

    public function car(){
        return $this->belongsTo(Car::class);
    }

    public function advert(){
        return $this->belongsTo(Advert::class);
    }

    public function weeks(){
        return $this->belongsToMany(Week::class,'caradvert_week');
    }

    public function checker(){
        return $this->belongsToMany(User::class);
    }
}
