<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Advert;
class Place extends Model
{
    //

    public function advert(){
        return $this->belongsToMany(Advert::class);
    }

    public function carsWorkingPlace(){
        return $this->belongsToMany(Car::class);
    }

    public function user(){
        return $this->belongsToMany(User::class);
    }
}
