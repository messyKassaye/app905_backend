<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\EntityType;
use App\Entity;
class Notification extends Model
{
    //

    public function entity(){
        return $this->belongsTo(Entity::class);
    }

    public function entityType(){
        return $this->belongsTo(EntityType::class,'entity_type_id');
    }
}
