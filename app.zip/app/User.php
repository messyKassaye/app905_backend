<?php

namespace App;

use App\Address;
use App\Company;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Tymon\JWTAuth\Contracts\JWTSubject;
use App\BankAccount;
class User extends Authenticatable implements JWTSubject
{
    use Notifiable;
    protected  $visible = ['id','first_name','last_name','email','phone','avator','status'];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
   

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Automatically creates hash for the user password.
     *
     * @param  string  $value
     * @return void
     */

     public function cars(){
         return $this->hasMany(Car::class,'user_id');
     }
     public function driverCar(){
         return $this->hasMany(Car::class,'driver_id');
     }

     public function advertiserSamples(){
         return $this->hasOne(AdvertisingEngineerSample::class);
     }

     public function advertiserPorfolios(){
         return $this->hasMany(AdvertisingEngineerPortfolio::class);
     }

     public function advertPayment(){
         return $this->hasMany(AdvertViewPayment::class,'payed_for');
     }

     public function role(){
         return $this->belongsToMany(Role::class);
     }


     public function finance(){
         return $this->hasMany(Finance::class);
     }

     public function balance(){
         return $this->hasOne(FinanceBalance::class);
     }

     public function payments(){
         return $this->hasMany(Payment::class);
     }

     public function withdrawal(){
         return $this->hasMany(Withdrawal::class);
     }

     public function deposit(){
         return $this->hasMany(Deposit::class);
     }

     public function banks(){
         return $this->hasMany(BankAccount::class);
     }

     public function companies(){
         return $this->hasMany(Company::class);
     }

     public function notifications(){
         return $this->hasMany(Notification::class,'actor_id');
     }

     public function place(){
         return $this->belongsToMany(Place::class);
     }

     public function downloadRequest(){
         return $this->hasMany(DownloadRequest::class);
     }
     public function downloads(){
         return $this->hasMany(Download::class);
     }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    public function setFirstNameAttribute($value){
         $this->attributes['first_name'] = ucfirst($value);
    }

    public function setLastNameAttribute($value){
         $this->attributes['last_name'] = ucfirst($value);
    }
    /**
     * Get the identifier that will be stored in the subject claim of the JWT.
     *
     * @return mixed
     */
    public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
}
