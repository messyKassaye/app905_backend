<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Notification;
class EntityType extends Model
{
    //

    public function notification(){
        return $this->hasMany(Notification::class);
    }
}
