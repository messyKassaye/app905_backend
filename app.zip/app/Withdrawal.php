<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Withdrawal extends Model
{
    //


    public function users(){
        return $this->belongsTo(User::class,'user_id');
    }

    public function payer(){
        return $this->belongsTo(User::class,'payer_id');
    }

    public function bank(){
        return $this->belongsTo(BankAccount::class,'bank_account_id');
    }
    public function assets(){
        return $this->hasMany(WithdrawalAssets::class);
    }
}
